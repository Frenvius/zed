export function main(): number {
	let s = '';
	return -1;
}