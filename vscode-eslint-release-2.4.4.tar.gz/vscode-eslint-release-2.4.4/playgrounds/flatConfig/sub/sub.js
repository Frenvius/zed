console.log(3 + 4);
console.log(undef);
