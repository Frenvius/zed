export function main(): number {
	let s: string = '';
	if (s == "") {
		return 0;
	}
	return -1;
}